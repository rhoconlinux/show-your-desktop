Snap Share
=================

In one move: Capture a desktop snapshot, Upload it to Imgur and get the url copied in your clipboard :)

Description
-----------

This is a simple app that once executed counts 4 seconds and take a screenshot. Without asking anything, it uploads automatically your shot to Imgur and when finish it copy the link of the URL in your clipboard. Share your desktop in one move :)

Using Snap-Share
--------------
There is a script called Snap-Share that was ment to feel what you are looking for. 
What it does exactly? well... 

0) Launch it:
<a href="http://imgur.com/kkf8ogr"><img src="http://i.imgur.com/kkf8ogr.png" title="Hosted by imgur.com"/></a>

1)it takes a picture
<a href="http://imgur.com/VlVnbDX"><img src="http://i.imgur.com/VlVnbDX.png" title="Hosted by imgur.com"/></a>

2)upload it, and 
<a href="http://imgur.com/f0f1jTb"><img src="http://i.imgur.com/f0f1jTb.png" title="Hosted by imgur.com" /></a>

3) copy the link in your clipboard. All in one move. 
<a href="http://imgur.com/kaUcrLA"><img src="http://i.imgur.com/kaUcrLA.png" title="Hosted by imgur.com"/></a>



See Snap-share working: 
-----------------------

In this video you can see **how to install** the program and **how it works** :)

**Click the image to go to the video!**
<center>[![Snap-share video](http://img.youtube.com/vi/7A-nDMINrGM/0.jpg)](http://www.youtube.com/watch?v=7A-nDMINrGM)</center>

How to install
=================

Just open a terminal and run this line. **IT IS ONE LINE**, so copy and paste carfully. You will be asked for sudo permissions to copy the downloaded files in /usr/bin/ and for install the dependencies. 

First run this to install the dependencies in Ubuntu and derivatives: 

    sudo apt-get install xsel scrot xclip

and then paste this:

    mkdir -p ~/.snap-share-install && cd ~/.snap-share-install && wget https://github.com/rhoconlinux/snap-share/archive/master.zip && unzip master.zip && rm master.zip &&  cd snap-share-master/ &&  chmod +x  install.sh && sh install.sh && cd ~ && clear

<a href="http://imgur.com/xce5uF2"><img src="http://i.imgur.com/xce5uF2.png" title="Hosted by imgur.com"/></a>

Then run it with your favourite launcher looking for snap-share. :)


Details
-------

This small script is based on this work: https://gist.github.com/kynan/2941720
I've just added a script to make the installation and use super simple. In one command. :)
The main stuff is based on this thread http://askubuntu.com/questions/146888/software-for-imgur-image-upload, with the proper fixes I comment. I also modified the orifinal "shoot" script to wait and take the shot automatically (instead of requiring you to select a part of your screen to capture). This is an alpha release. 
